""" 
    Multiplica 1011 por 110.
    Multiplica 1100 por 101.
    Multiplica 1001 por 11.
    Multiplica 10101 por 100.
    Multiplica 11111 por 111.
    Multiplica un número binario de 4 dígitos (1010) por otro número binario de 4 dígitos (1101).
"""


def binary_multiply(bin1, bin2):
    num1 = int(bin1, 2)
    num2 = int(bin2, 2)

    result = num1 * num2

    result_bin = bin(result)[2:]

    return result_bin


while True:
    b1 = input("Ingresa el primer número binario: ")
    b2 = input("Ingresa el segundo número binario: ")
    resultado_bin = binary_multiply(b1, b2)
    print("El resultado de la multiplicación de",
          b1, "y", b2, "es:", resultado_bin)
